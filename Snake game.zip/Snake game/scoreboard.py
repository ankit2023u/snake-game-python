from turtle import Turtle
ALIGNMENT = 'center'
FONT = ('Arial', 14, 'bold')


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.score = 0
        self.hideturtle()
        self.pencolor('white')
        self.penup()
        self.goto(0,270)
        self.update_score()

    def game_over(self):
        self.goto(0,0)
        self.write(arg='GAME OVER', align=ALIGNMENT, font=FONT)

    def update_score(self):
        current_score = f'Score: {self.score}'
        self.clear()
        self.write(arg=current_score, align=ALIGNMENT, font=FONT)
        self.score += 1