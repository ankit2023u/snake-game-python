import time
import food as f
import snake as s
import scoreboard as sb
from turtle import Screen

window = Screen()
window.setup(width=600, height=600)
window.bgcolor("black")
window.title("SNAKE GAME")
window.tracer(0)

allowed_colors = ['red','violet','pink','white','yellow','green','blue','brown','orange']
food_color = window.textinput('Food Color', 'Enter The Color Of Food: ').lower()
snake_color = window.textinput('Snake Color', 'Enter The Color Of Snake: ').lower()

if food_color not in allowed_colors or snake_color not in allowed_colors:
    window.textinput('Wrong Input', 'Press Enter To Continue')
    food_color = 'cyan'
    snake_color = 'white'

snake = s.Snake(snake_color)
food = f.Food(food_color)
scoreboard = sb.Scoreboard()

window.listen()
window.onkey(snake.up, "Up")
window.onkey(snake.down, "Down")
window.onkey(snake.left, "Left")
window.onkey(snake.right, "Right")

game_over = False
while not game_over:
    window.update()
    time.sleep(0.12)
    snake.move()

    if snake.head.distance(food) < 15:
        food.change_position()
        snake.extend_snake()
        scoreboard.update_score()

    if snake.head.xcor() > 290 or snake.head.ycor() > 290 or snake.head.xcor() < -290 or snake.head.ycor() < -290:
        game_over = True
        scoreboard.game_over()

    for part in snake.snake_body[1:]:
        if snake.head.distance(part) < 10:
            game_over = True
            scoreboard.game_over()

window.exitonclick()
