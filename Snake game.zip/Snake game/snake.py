from turtle import Turtle
MOVE_DISTANCE = 20
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0


class Snake:

    def __init__(self, color='white'):
        self.color = color
        self.snake_body = []
        self.create_snake()
        self.head = self.snake_body[0]
        # self.head.color('yellow')

    def create_snake(self):
        for i in range(3):
            pos = (-20*i, 0)
            self.add_part(pos)

    def add_part(self, position):
        snake_part = Turtle(shape='square')
        snake_part.color(self.color)
        snake_part.penup()
        snake_part.goto(position)
        self.snake_body.append(snake_part)

    def extend_snake(self):
        self.add_part(self.snake_body[-1].position())

    def move(self):
        for part_num in range(len(self.snake_body)-1, 0, -1):
            new_position = self.snake_body[part_num-1].position()
            self.snake_body[part_num].goto(new_position)
        self.head.forward(MOVE_DISTANCE)

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)
